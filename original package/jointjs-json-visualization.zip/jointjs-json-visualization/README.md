# JointJS+: JSON Visualization

A Pen created on CodePen.io. Original URL: [https://codepen.io/jointjs/pen/WNJBMxQ](https://codepen.io/jointjs/pen/WNJBMxQ).

Today's CodePen shows how to write a simple JSON visualizer using JointJS+. Use TreeLayout to automatically position nodes and add Record shapes to organize object properties into tables where values have different styles depending on their type.